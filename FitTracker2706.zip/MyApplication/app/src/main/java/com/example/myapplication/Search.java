package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

public class Search extends NavMenu implements AdapterView.OnItemSelectedListener{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_test);
        getLayoutInflater().inflate(R.layout.nav_search,constraintLayout);

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
