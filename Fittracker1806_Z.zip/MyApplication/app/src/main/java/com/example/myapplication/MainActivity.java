package com.example.myapplication;


import android.os.Bundle;




public class MainActivity extends NavMenu {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.activity_main,constraintLayout);

        navigationView.getMenu().getItem(0).setChecked(true);
    }
}