package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;


public class UebungAnlegen extends NavMenu implements AdapterView.OnItemSelectedListener {

    private Spinner spinner_einheiten;
    //@Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_uebunganlegen);

        getLayoutInflater().inflate(R.layout.activity_uebunganlegen,constraintLayout);

        ArrayAdapter<CharSequence> adapter_einheiten = ArrayAdapter.createFromResource(this, R.array.einheiten, android.R.layout.simple_spinner_dropdown_item);
        adapter_einheiten.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner_einheiten = findViewById(R.id.spinner1);

        spinner_einheiten.setAdapter(adapter_einheiten);
        spinner_einheiten.setOnItemSelectedListener(this);

        spinner_einheiten = findViewById(R.id.spinner2);

        spinner_einheiten.setAdapter(adapter_einheiten);
        spinner_einheiten.setOnItemSelectedListener(this);

        spinner_einheiten = findViewById(R.id.spinner3);

        spinner_einheiten.setAdapter(adapter_einheiten);
        spinner_einheiten.setOnItemSelectedListener(this);

        spinner_einheiten = findViewById(R.id.spinner4);

        spinner_einheiten.setAdapter(adapter_einheiten);
        spinner_einheiten.setOnItemSelectedListener(this);

        spinner_einheiten = findViewById(R.id.spinner5);

        spinner_einheiten.setAdapter(adapter_einheiten);
        spinner_einheiten.setOnItemSelectedListener(this);

        spinner_einheiten = findViewById(R.id.spinner6);

        spinner_einheiten.setAdapter(adapter_einheiten);
        spinner_einheiten.setOnItemSelectedListener(this);

        navigationView.getMenu().getItem(1).setChecked(true);

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}