package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

public class Settings extends NavMenu implements AdapterView.OnItemSelectedListener{
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


        getLayoutInflater().inflate(R.layout.settings,constraintLayout);


    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
