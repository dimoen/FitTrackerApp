package com.example.myapplication;


import static android.content.ContentValues.TAG;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import android.os.Environment;


public class DataManager {
    private List<Übung> exercises_List ;
    private List<Workout> workouts_List;
    JsonIO io = new JsonIO();


    public DataManager() {
        exercises_List = new ArrayList<Übung>(); // Initialisiere die exercises-Liste
        //loadExercises();
        try {
            io.saveWeight(5.3);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            io.getWeight();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }



    public void saveAll(){
        Log.d(TAG, "saveAll successfully.");

        try {

            io.dumpExercises(exercises_List);

            //io.saveWeight();
            io.dumpWorkouts(workouts_List);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


    public void addExercise(Übung exerciseNew) {
        boolean exerciseExists = false;

        // Iterate over the existing exercises to check if an exercise with the same name exists
        for (Übung exercise : exercises_List) {
            if (exercise.getName().equals(exerciseNew.getName())) {
                exerciseExists = true;
                break;
            }
        }

        if (exerciseExists) {
            Log.d(TAG, "Exercise with the name '" + exerciseNew.getName() + "' already exists.");
        } else {
            exercises_List.add(exerciseNew);
            Log.d(TAG, "Exercise added successfully.");
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            File file = new File(path, "/" + fname);
            Log.i("MENU_DRAWER_TAG :::::: ADDEXERCISE PAAATH", file.getPath());

            // Save the exercises to the JSON file
            saveAll();

        }
    }

    //!!
    public void addWorkout(Workout WorkoutNew) {
        boolean exerciseExists = false;

        // Iterate over the existing exercises to check if an exercise with the same name exists
        for (Übung exercise : exercises_List) {
            if (exercise.getName().equals(WorkoutNew.getName())) {
                exerciseExists = true;
                break;
            }
        }

        if (exerciseExists) {
            Log.d(TAG, "Exercise with the name '" + WorkoutNew.getName() + "' already exists.");
        } else {
            workouts_List.add(WorkoutNew);
            Log.d(TAG, "Exercise added successfully.");

            // Save the exercises to the JSON file
            saveAll();
        }
    }








}
