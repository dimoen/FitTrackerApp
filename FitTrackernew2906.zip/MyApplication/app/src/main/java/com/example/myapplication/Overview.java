package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;

public class Overview extends NavMenu implements AdapterView.OnItemSelectedListener{
    private Button exercisesButton;
    private Button workoutsButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_test);
        getLayoutInflater().inflate(R.layout.overview,constraintLayout);
        exercisesButton = findViewById(R.id.exercisesButton);
        workoutsButton = findViewById(R.id.workoutsButton);

        //exercisesButton.setOnClickListener(this);
        //workoutsButton.setOnClickListener(this);

    }




    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
